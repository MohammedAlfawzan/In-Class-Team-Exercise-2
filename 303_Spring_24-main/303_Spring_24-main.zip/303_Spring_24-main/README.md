# Pair Exercise #4

## Ahmed Alanazi
## Mohammed Alfawzan


# wikipedia 

![PE04](https://github.com/Ahmed5641/303_Spring_24/assets/157667926/fcb01751-012e-43e2-adc8-33f67d8a3e5c)




# Funtions_Exercise:

![Capture1](https://github.com/Ahmed5641/303_Spring_24/assets/157667926/8a4c5a47-48c5-4e3f-9ab2-d2db5f8cd3eb)

![Capture2](https://github.com/Ahmed5641/303_Spring_24/assets/157667926/03601e1e-b390-4a65-bcbf-2b6cf99ee6e1)


# Classes_Exercise:

![Capture4](https://github.com/Ahmed5641/303_Spring_24/assets/157667926/027181b1-e810-45cd-96ed-431af8b5609b)


